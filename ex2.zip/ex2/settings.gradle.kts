
rootProject.name = "ex2"

