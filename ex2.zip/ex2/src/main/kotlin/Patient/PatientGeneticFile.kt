// PatientGeneticFile.kt

data class PatientGeneticFile(){
    private var hasBRCA: Boolean

    fun hasBRCA(): Boolean {
        return hasBRCA
    }
}